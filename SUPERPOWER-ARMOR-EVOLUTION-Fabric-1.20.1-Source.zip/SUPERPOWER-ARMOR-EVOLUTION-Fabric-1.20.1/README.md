# SUPERPOWER & ARMOR EVOLUTION — Fabric 1.20.1

Mod Fabric bertema superhero original. Menambahkan lima set armor lengkap dengan tekstur buatan sendiri, efek pasif, dan skill aktif.

## Persyaratan
- Minecraft Java Edition **1.20.1**
- Fabric Loader **0.15.11 atau lebih baru yang kompatibel dengan 1.20.1**
- Fabric API **0.92.12+1.20.1**
- Java **17** untuk build

## Set armor dan kekuatan

| Armor | Kekuatan pasif (4 bagian) | Skill aktif (R) |
|---|---|---|
| **Energy Armor** | Absorption I | **Energy Surge** — Resistance II dan Absorption II selama 8 detik |
| **Lightning Armor** | Speed II dan Jump Boost I | **Lightning Overdrive** — Speed III dan Jump Boost II selama 8 detik |
| **Cosmic Armor** | Resistance I dan Night Vision | **Cosmic Renewal** — Regeneration II dan Resistance II selama 8 detik |
| **Shadow Armor** | Speed I dan Night Vision | **Shadow Veil** — Invisibility dan Speed II selama 8 detik |
| **Fire Armor** | Fire Resistance dan Strength I | **Inferno Core** — Fire Resistance dan Strength II selama 8 detik |

Semua skill aktif memiliki cooldown **15 detik** dan hanya aktif saat empat bagian dari set yang sama sedang dipakai.

## Build JAR melalui GitHub Actions
1. Buat repository GitHub baru.
2. Ekstrak semua isi ZIP ini ke root repository. Pastikan `build.gradle`, `gradle.properties`, `settings.gradle`, dan folder `.github` berada langsung di root.
3. Commit dan push ke repository, atau buka tab **Actions** lalu jalankan workflow secara manual.
4. Setelah workflow berhasil, buka hasil workflow dan unduh artifact **SUPERPOWER-ARMOR-EVOLUTION-Fabric-1.20.1**.
5. Pasang file JAR di folder `mods` Minecraft Fabric 1.20.1. Fabric API juga harus terpasang.

Workflow ada di `.github/workflows/build.yml` dan menggunakan Java 17 serta Gradle 8.8.

## Kontrol
Tekan **R** untuk mengaktifkan skill. Tombolnya dapat diubah di **Options → Controls → Key Binds**.

## Isi source
20 item armor, 20 resep crafting, 10 tekstur model armor, 20 ikon item, ikon mod, bahasa Inggris dan Indonesia, serta workflow build.

**Catatan:** ZIP ini adalah source project, bukan JAR jadi. GitHub Actions akan membuat file JAR setelah source di-push dan workflow dijalankan.
