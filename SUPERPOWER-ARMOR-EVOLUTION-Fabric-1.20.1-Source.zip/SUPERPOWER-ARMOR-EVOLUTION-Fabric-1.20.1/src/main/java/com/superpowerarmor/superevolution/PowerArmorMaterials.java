package com.superpowerarmor.superevolution;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public enum PowerArmorMaterials implements ArmorMaterial {
    ENERGY("energy", 38, 20, 2.5F, 0.10F, Ingredient.ofItems(Items.AMETHYST_SHARD)),
    LIGHTNING("lightning", 36, 18, 2.0F, 0.08F, Ingredient.ofItems(Items.COPPER_INGOT)),
    COSMIC("cosmic", 40, 22, 3.0F, 0.12F, Ingredient.ofItems(Items.ENDER_PEARL)),
    SHADOW("shadow", 35, 18, 2.0F, 0.08F, Ingredient.ofItems(Items.ECHO_SHARD)),
    FIRE("fire", 38, 20, 2.5F, 0.10F, Ingredient.ofItems(Items.BLAZE_POWDER));

    private final String name;
    private final int durabilityMultiplier;
    private final int enchantability;
    private final float toughness;
    private final float knockbackResistance;
    private final Ingredient repairIngredient;

    PowerArmorMaterials(String name, int durabilityMultiplier, int enchantability,
                        float toughness, float knockbackResistance, Ingredient repairIngredient) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.enchantability = enchantability;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repairIngredient = repairIngredient;
    }

    @Override
    public int getDurability(ArmorItem.Type type) {
        int baseDurability = switch (type) {
            case HELMET -> 11;
            case CHESTPLATE -> 16;
            case LEGGINGS -> 15;
            case BOOTS -> 13;
        };
        return baseDurability * durabilityMultiplier;
    }

    @Override
    public int getProtection(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> 3;
            case CHESTPLATE -> 8;
            case LEGGINGS -> 6;
            case BOOTS -> 3;
        };
    }

    @Override
    public int getEnchantability() {
        return enchantability;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return repairIngredient;
    }

    @Override
    public String getName() {
        return "superpower_armor_evolution:" + name;
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return knockbackResistance;
    }
}
