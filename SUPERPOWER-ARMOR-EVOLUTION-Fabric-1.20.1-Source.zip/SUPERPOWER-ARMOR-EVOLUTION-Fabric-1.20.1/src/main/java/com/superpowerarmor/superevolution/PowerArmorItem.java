package com.superpowerarmor.superevolution;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Item;

public class PowerArmorItem extends ArmorItem {
    private final PowerSet powerSet;

    public PowerArmorItem(ArmorMaterial material, Type type, Item.Settings settings, PowerSet powerSet) {
        super(material, type, settings);
        this.powerSet = powerSet;
    }

    public PowerSet getPowerSet() {
        return powerSet;
    }
}
