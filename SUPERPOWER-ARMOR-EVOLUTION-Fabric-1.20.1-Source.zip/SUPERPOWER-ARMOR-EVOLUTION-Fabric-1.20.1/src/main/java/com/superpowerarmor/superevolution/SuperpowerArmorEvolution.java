package com.superpowerarmor.superevolution;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.particle.ParticleTypes;

public class SuperpowerArmorEvolution implements ModInitializer {
    public static final String MOD_ID = "superpower_armor_evolution";
    public static final Identifier ACTIVATE_ABILITY_PACKET = new Identifier(MOD_ID, "activate_ability");
    private static final long ABILITY_COOLDOWN_TICKS = 20L * 15L;
    private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();

    @Override
    public void onInitialize() {
        ModItems.initialize();

        ServerPlayNetworking.registerGlobalReceiver(ACTIVATE_ABILITY_PACKET,
                (server, player, handler, buf, responseSender) -> server.execute(() -> activateAbility(player)));

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                if (player.getWorld().getTime() % 40L == 0L) {
                    applyPassivePower(player);
                }
            }
        });
    }

    private static PowerSet getCompleteSet(PlayerEntity player) {
        ItemStack helmet = player.getEquippedStack(EquipmentSlot.HEAD);
        ItemStack chest = player.getEquippedStack(EquipmentSlot.CHEST);
        ItemStack legs = player.getEquippedStack(EquipmentSlot.LEGS);
        ItemStack boots = player.getEquippedStack(EquipmentSlot.FEET);

        if (!(helmet.getItem() instanceof PowerArmorItem helmetItem)
                || !(chest.getItem() instanceof PowerArmorItem chestItem)
                || !(legs.getItem() instanceof PowerArmorItem legsItem)
                || !(boots.getItem() instanceof PowerArmorItem bootsItem)) {
            return null;
        }

        PowerSet set = helmetItem.getPowerSet();
        return chestItem.getPowerSet() == set && legsItem.getPowerSet() == set && bootsItem.getPowerSet() == set
                ? set : null;
    }

    private static void applyPassivePower(ServerPlayerEntity player) {
        PowerSet set = getCompleteSet(player);
        if (set == null) return;

        switch (set) {
            case ENERGY -> addEffect(player, StatusEffects.ABSORPTION, 80, 0);
            case LIGHTNING -> {
                addEffect(player, StatusEffects.SPEED, 80, 1);
                addEffect(player, StatusEffects.JUMP_BOOST, 80, 0);
            }
            case COSMIC -> {
                addEffect(player, StatusEffects.RESISTANCE, 80, 0);
                addEffect(player, StatusEffects.NIGHT_VISION, 300, 0);
            }
            case SHADOW -> {
                addEffect(player, StatusEffects.SPEED, 80, 0);
                addEffect(player, StatusEffects.NIGHT_VISION, 300, 0);
            }
            case FIRE -> {
                addEffect(player, StatusEffects.FIRE_RESISTANCE, 80, 0);
                addEffect(player, StatusEffects.STRENGTH, 80, 0);
            }
        }
    }

    private static void addEffect(ServerPlayerEntity player, net.minecraft.entity.effect.StatusEffect effect,
                                  int duration, int amplifier) {
        player.addStatusEffect(new StatusEffectInstance(effect, duration, amplifier, true, false, true));
    }

    public static void activateAbility(ServerPlayerEntity player) {
        PowerSet set = getCompleteSet(player);
        if (set == null) {
            player.sendMessage(Text.literal("Wear one complete Superpower armor set to use its ability."), true);
            return;
        }

        long now = player.getServerWorld().getTime();
        long nextReady = COOLDOWNS.getOrDefault(player.getUuid(), 0L);
        if (now < nextReady) {
            long seconds = Math.max(1L, (nextReady - now + 19L) / 20L);
            player.sendMessage(Text.literal("Ability recharging: " + seconds + "s"), true);
            return;
        }

        COOLDOWNS.put(player.getUuid(), now + ABILITY_COOLDOWN_TICKS);
        ServerWorld world = player.getServerWorld();

        switch (set) {
            case ENERGY -> {
                addEffect(player, StatusEffects.RESISTANCE, 160, 1);
                addEffect(player, StatusEffects.ABSORPTION, 160, 1);
                world.spawnParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0, player.getZ(), 42, 0.7, 0.9, 0.7, 0.04);
                player.sendMessage(Text.literal("ENERGY SURGE activated!"), true);
            }
            case LIGHTNING -> {
                addEffect(player, StatusEffects.SPEED, 160, 2);
                addEffect(player, StatusEffects.JUMP_BOOST, 160, 1);
                world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, player.getX(), player.getY() + 1.0, player.getZ(), 48, 0.8, 0.9, 0.8, 0.08);
                player.sendMessage(Text.literal("LIGHTNING OVERDRIVE activated!"), true);
            }
            case COSMIC -> {
                addEffect(player, StatusEffects.REGENERATION, 160, 1);
                addEffect(player, StatusEffects.RESISTANCE, 160, 1);
                world.spawnParticles(ParticleTypes.REVERSE_PORTAL, player.getX(), player.getY() + 1.0, player.getZ(), 56, 0.8, 1.0, 0.8, 0.05);
                player.sendMessage(Text.literal("COSMIC RENEWAL activated!"), true);
            }
            case SHADOW -> {
                addEffect(player, StatusEffects.INVISIBILITY, 160, 0);
                addEffect(player, StatusEffects.SPEED, 160, 1);
                world.spawnParticles(ParticleTypes.LARGE_SMOKE, player.getX(), player.getY() + 1.0, player.getZ(), 40, 0.7, 0.9, 0.7, 0.02);
                player.sendMessage(Text.literal("SHADOW VEIL activated!"), true);
            }
            case FIRE -> {
                addEffect(player, StatusEffects.FIRE_RESISTANCE, 240, 0);
                addEffect(player, StatusEffects.STRENGTH, 160, 1);
                world.spawnParticles(ParticleTypes.FLAME, player.getX(), player.getY() + 1.0, player.getZ(), 48, 0.7, 0.9, 0.7, 0.03);
                player.sendMessage(Text.literal("INFERNO CORE activated!"), true);
            }
        }
    }
}
