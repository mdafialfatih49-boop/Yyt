package com.superpowerarmor.superevolution;

public enum PowerSet {
    ENERGY("Energy"),
    LIGHTNING("Lightning"),
    COSMIC("Cosmic"),
    SHADOW("Shadow"),
    FIRE("Fire");

    private final String displayName;

    PowerSet(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
