package com.superpowerarmor.superevolution;

import java.util.ArrayList;
import java.util.List;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModItems {
    private static final List<Item> ALL_ARMOR = new ArrayList<>();

    public static final Item ENERGY_HELMET = register("energy_helmet", PowerArmorMaterials.ENERGY, ArmorItem.Type.HELMET, PowerSet.ENERGY);
    public static final Item ENERGY_CHESTPLATE = register("energy_chestplate", PowerArmorMaterials.ENERGY, ArmorItem.Type.CHESTPLATE, PowerSet.ENERGY);
    public static final Item ENERGY_LEGGINGS = register("energy_leggings", PowerArmorMaterials.ENERGY, ArmorItem.Type.LEGGINGS, PowerSet.ENERGY);
    public static final Item ENERGY_BOOTS = register("energy_boots", PowerArmorMaterials.ENERGY, ArmorItem.Type.BOOTS, PowerSet.ENERGY);

    public static final Item LIGHTNING_HELMET = register("lightning_helmet", PowerArmorMaterials.LIGHTNING, ArmorItem.Type.HELMET, PowerSet.LIGHTNING);
    public static final Item LIGHTNING_CHESTPLATE = register("lightning_chestplate", PowerArmorMaterials.LIGHTNING, ArmorItem.Type.CHESTPLATE, PowerSet.LIGHTNING);
    public static final Item LIGHTNING_LEGGINGS = register("lightning_leggings", PowerArmorMaterials.LIGHTNING, ArmorItem.Type.LEGGINGS, PowerSet.LIGHTNING);
    public static final Item LIGHTNING_BOOTS = register("lightning_boots", PowerArmorMaterials.LIGHTNING, ArmorItem.Type.BOOTS, PowerSet.LIGHTNING);

    public static final Item COSMIC_HELMET = register("cosmic_helmet", PowerArmorMaterials.COSMIC, ArmorItem.Type.HELMET, PowerSet.COSMIC);
    public static final Item COSMIC_CHESTPLATE = register("cosmic_chestplate", PowerArmorMaterials.COSMIC, ArmorItem.Type.CHESTPLATE, PowerSet.COSMIC);
    public static final Item COSMIC_LEGGINGS = register("cosmic_leggings", PowerArmorMaterials.COSMIC, ArmorItem.Type.LEGGINGS, PowerSet.COSMIC);
    public static final Item COSMIC_BOOTS = register("cosmic_boots", PowerArmorMaterials.COSMIC, ArmorItem.Type.BOOTS, PowerSet.COSMIC);

    public static final Item SHADOW_HELMET = register("shadow_helmet", PowerArmorMaterials.SHADOW, ArmorItem.Type.HELMET, PowerSet.SHADOW);
    public static final Item SHADOW_CHESTPLATE = register("shadow_chestplate", PowerArmorMaterials.SHADOW, ArmorItem.Type.CHESTPLATE, PowerSet.SHADOW);
    public static final Item SHADOW_LEGGINGS = register("shadow_leggings", PowerArmorMaterials.SHADOW, ArmorItem.Type.LEGGINGS, PowerSet.SHADOW);
    public static final Item SHADOW_BOOTS = register("shadow_boots", PowerArmorMaterials.SHADOW, ArmorItem.Type.BOOTS, PowerSet.SHADOW);

    public static final Item FIRE_HELMET = register("fire_helmet", PowerArmorMaterials.FIRE, ArmorItem.Type.HELMET, PowerSet.FIRE);
    public static final Item FIRE_CHESTPLATE = register("fire_chestplate", PowerArmorMaterials.FIRE, ArmorItem.Type.CHESTPLATE, PowerSet.FIRE);
    public static final Item FIRE_LEGGINGS = register("fire_leggings", PowerArmorMaterials.FIRE, ArmorItem.Type.LEGGINGS, PowerSet.FIRE);
    public static final Item FIRE_BOOTS = register("fire_boots", PowerArmorMaterials.FIRE, ArmorItem.Type.BOOTS, PowerSet.FIRE);

    private ModItems() {}

    private static Item register(String name, PowerArmorMaterials material, ArmorItem.Type type, PowerSet powerSet) {
        Item item = Registry.register(Registries.ITEM,
                new Identifier(SuperpowerArmorEvolution.MOD_ID, name),
                new PowerArmorItem(material, type, new Item.Settings().maxCount(1), powerSet));
        ALL_ARMOR.add(item);
        return item;
    }

    public static void initialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> ALL_ARMOR.forEach(entries::add));
    }
}
