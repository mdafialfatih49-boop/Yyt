package com.superpowerarmor.superevolution;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import org.lwjgl.glfw.GLFW;

public class SuperpowerArmorEvolutionClient implements ClientModInitializer {
    private static KeyBinding activateAbilityKey;

    @Override
    public void onInitializeClient() {
        activateAbilityKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.superpower_armor_evolution.activate_ability",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.superpower_armor_evolution"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (activateAbilityKey.wasPressed()) {
                if (client.player != null) {
                    ClientPlayNetworking.send(SuperpowerArmorEvolution.ACTIVATE_ABILITY_PACKET, PacketByteBufs.empty());
                }
            }
        });
    }
}
